<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div class="wrapper-page">
		<div id="menu-mobile" style="display:none;">
			<?php px_nav_menu('mobile'); ?>
		</div>
		<div class="wrapper-inside">
			<header id="header">
				<div class="container">
					<div class="logo">
						<a href="<?php bloginfo('url'); ?>"><?php px_logo(); ?></a>
					</div>
					<?php px_nav_menu(); ?>
					<div class="appie-btn-box text-right"><a class="main-btn ml-30 dlink" href="javascript:;">Get Started <i class="right-click"></i></a>
						<div class="toggle-btn ml-30 d-lg-none d-block"><i class="fa menu_click"></i></div>
					</div>
				</div>
			</header>
		</div>
		<section class="appie-hero-area">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="appie-hero-content" style="padding-right:40px;">
							<?php get_template_part('template-parts/searchform'); ?>
							<h1 class="appie-title" style="margin-top:100px;">HappyMod</h1>
							<div class="dlink" style="margin-top:10px;">
								<div style="width:300px;" class="hmbtn_box">
									<div style="position:absolute;margin:20px 0 0 243px;width:40px;height:40px;border-radius:100%;background:#2F670B;">
									<img src="<?php echo THEME_URL . '-child/assets/icons/arrow-index.png' ?>" width="24" height="24" style="margin:9px 0 0 9px;" class="bounce" alt="download"></div>
									<img class="index_header_bg" src="<?php echo THEME_URL . '-child/assets/icons/bg.png' ?>" width="300" height="78" alt="button">
								</div>
							</div>
							<p id="header-hm-content">Published on: Apr 17, 2024<br>Latest version: 3.1.0<br>Size: 16.2 MB<br></p>
						</div>
					</div>
					<div class="col-lg-6" style="text-align:center;">
					<img src="<?php echo THEME_URL . '-child/assets/icons/hero_index.webp' ?>" class="hero_thumb lozad" width="510" height="566" alt="HappyMod" data-loaded="true">
				</div>
				</div>
			</div>
		</section>
		<?php
		if (!isset($args['ws'])) {
			// do_action('subheader');
			echo px_ads('ads_header');
		} ?>
		<main id="main-site">
