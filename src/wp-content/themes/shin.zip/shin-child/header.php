<?php 
if( is_amp_px() ) { 
	get_template_part( 'template-parts/header' ); 
} else {
	get_header( 'default' ); 
}
