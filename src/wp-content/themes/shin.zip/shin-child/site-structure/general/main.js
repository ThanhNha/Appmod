const shin = 0;
